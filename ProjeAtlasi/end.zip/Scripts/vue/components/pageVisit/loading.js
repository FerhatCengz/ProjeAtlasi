export const LoadingPageComponent = {
  template: `
  <div class="custom-loader centerDiv"></div>
`,
};
